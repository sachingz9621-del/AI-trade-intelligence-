# AI Trade Intelligence V6 — Multi-Timeframe Scanner & Risk Sizer

V6 continues from the V5 Index & Options Signal Desk. It adds a separate scanner page and a transparent cash-equity position risk calculator.

## Added in V6
- Scan up to 12 user-entered Yahoo Finance symbols.
- Compare daily (1y) and hourly (60d) technical context.
- Display per-timeframe bullish / bearish / neutral bias and an alignment summary.
- Download scan results as CSV.
- Cash-equity share sizing from entry, stop, available capital and risk percentage.
- Unit tests for alignment and risk-sizing calculations.

## Run
From the `AI_Trade_Intelligence` folder:

```bash
python -m pip install -r requirements.txt
python -m streamlit run app.py
```

## Validate
```bash
python -m unittest -v test_multi_timeframe_engine.py test_index_options_intelligence.py test_market_intelligence.py
```

## Important limitations
- This is rule-based technical decision support, not a trained machine-learning model and not a probability forecast.
- Scanner data is fetched from Yahoo Finance; it may be delayed, incomplete, rate-limited or unavailable. Verify quotes and timestamps with your broker.
- The risk calculator is for cash-equity share quantities only. It excludes brokerage, taxes, slippage, gaps, liquidity and leverage. It must not be used as an options-lot calculator.
- No order placement or live NSE options-chain connection is added in V6.
- Keep broker API tokens only in your local `.streamlit/secrets.toml`; never share secrets in ZIP files.
