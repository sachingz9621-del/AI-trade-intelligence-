"""V40 chronological strategy backtesting lab.

Signals are calculated from completed candles and shifted one bar before they
can affect returns. This avoids using the current candle's close to earn that
same candle's return. All results are historical simulations, not forecasts.
"""
from __future__ import annotations
import numpy as np
import pandas as pd

STRATEGIES = ["EMA Crossover", "RSI Mean Reversion", "Donchian Breakout"]


def _validate_ohlcv(frame: pd.DataFrame) -> pd.DataFrame:
    required = {"Open", "High", "Low", "Close", "Volume"}
    if not isinstance(frame, pd.DataFrame) or not required.issubset(frame.columns):
        raise ValueError("OHLCV data must contain Open, High, Low, Close and Volume columns.")
    x = frame.copy().sort_index()
    for col in required:
        x[col] = pd.to_numeric(x[col], errors="coerce")
    x = x.replace([np.inf, -np.inf], np.nan).dropna(subset=["Open", "High", "Low", "Close"])
    x = x[(x.Close > 0) & (x.Open > 0) & (x.High > 0) & (x.Low > 0)]
    if len(x) < 60:
        raise ValueError(f"At least 60 clean candles are required; found {len(x)}.")
    return x


def build_signals(frame: pd.DataFrame, strategy: str = "EMA Crossover", *,
                  fast: int = 10, slow: int = 30, rsi_period: int = 14,
                  oversold: float = 30, overbought: float = 70,
                  breakout_window: int = 20, allow_short: bool = False) -> pd.Series:
    x = _validate_ohlcv(frame)
    close = x.Close
    if strategy == "EMA Crossover":
        if fast < 2 or slow <= fast:
            raise ValueError("EMA settings must satisfy 2 <= fast < slow.")
        f = close.ewm(span=int(fast), adjust=False).mean()
        s = close.ewm(span=int(slow), adjust=False).mean()
        sig = pd.Series(np.where(f > s, 1.0, -1.0 if allow_short else 0.0), index=x.index)
        if allow_short:
            sig = pd.Series(np.where(f > s, 1.0, -1.0), index=x.index)
    elif strategy == "RSI Mean Reversion":
        if rsi_period < 2 or not (0 < oversold < 50 < overbought < 100):
            raise ValueError("RSI period must be >=2; thresholds must satisfy 0 < oversold < 50 < overbought < 100.")
        delta = close.diff()
        gain = delta.clip(lower=0).ewm(alpha=1 / rsi_period, adjust=False).mean()
        loss = (-delta.clip(upper=0)).ewm(alpha=1 / rsi_period, adjust=False).mean()
        rsi = 100 - 100 / (1 + gain / loss.replace(0, np.nan))
        state = 0.0
        values = []
        for value in rsi:
            if pd.notna(value):
                if value <= oversold:
                    state = 1.0
                elif value >= 50:
                    state = 0.0
                if allow_short and value >= overbought:
                    state = -1.0
                elif allow_short and value <= 50 and state == -1.0:
                    state = 0.0
            values.append(state)
        sig = pd.Series(values, index=x.index, dtype=float)
    elif strategy == "Donchian Breakout":
        if breakout_window < 5:
            raise ValueError("Breakout window must be at least 5 candles.")
        prior_high = x.High.rolling(int(breakout_window), min_periods=int(breakout_window)).max().shift(1)
        prior_low = x.Low.rolling(int(breakout_window), min_periods=int(breakout_window)).min().shift(1)
        state = 0.0
        values = []
        for c, hi, lo in zip(close, prior_high, prior_low):
            if pd.notna(hi) and c > hi:
                state = 1.0
            elif pd.notna(lo) and c < lo:
                state = -1.0 if allow_short else 0.0
            values.append(state)
        sig = pd.Series(values, index=x.index, dtype=float)
    else:
        raise ValueError(f"Unsupported strategy. Choose one of: {', '.join(STRATEGIES)}.")
    return sig.fillna(0.0).clip(-1, 1).rename("signal_at_close")


def _trade_segments(close: pd.Series, positions: pd.Series, net_returns: pd.Series):
    rows = []
    pos = positions.fillna(0).astype(float)
    start = None
    direction = 0.0
    for i in range(len(pos) + 1):
        current = float(pos.iloc[i]) if i < len(pos) else 0.0
        if start is not None and (current != direction):
            end = i - 1
            entry_i = max(start - 1, 0)
            entry = float(close.iloc[entry_i])
            exit_price = float(close.iloc[end])
            segment = net_returns.iloc[start:end + 1]
            net_return = float((1.0 + segment).prod() - 1.0)
            rows.append({"Entry date": str(close.index[start]), "Exit date": str(close.index[end]),
                         "Side": "LONG" if direction > 0 else "SHORT", "Entry reference": entry,
                         "Exit reference": exit_price, "Net return %": net_return * 100,
                         "Bars held": end - start + 1, "Result": "WIN" if net_return > 0 else "LOSS" if net_return < 0 else "FLAT"})
            start = None
        if current != 0 and start is None:
            start, direction = i, current
    return pd.DataFrame(rows)


def run_backtest(frame: pd.DataFrame, strategy: str = "EMA Crossover", *,
                 initial_capital: float = 100000, cost_bps: float = 10.0,
                 fast: int = 10, slow: int = 30, rsi_period: int = 14,
                 oversold: float = 30, overbought: float = 70,
                 breakout_window: int = 20, allow_short: bool = False,
                 test_fraction: float = 0.30):
    x = _validate_ohlcv(frame)
    if initial_capital <= 0 or cost_bps < 0:
        raise ValueError("Initial capital must be positive and costs cannot be negative.")
    if not 0.10 <= test_fraction <= 0.50:
        raise ValueError("Out-of-sample fraction must be between 0.10 and 0.50.")
    signals = build_signals(x, strategy, fast=fast, slow=slow, rsi_period=rsi_period,
                            oversold=oversold, overbought=overbought,
                            breakout_window=breakout_window, allow_short=allow_short)
    # Signal from completed candle t is applied to the return from t to t+1.
    positions = signals.shift(1).fillna(0.0)
    returns = x.Close.pct_change().fillna(0.0)
    turnover = positions.diff().abs()
    if len(turnover):
        turnover.iloc[0] = abs(float(positions.iloc[0]))
    costs = turnover.fillna(0.0) * (float(cost_bps) / 10000.0)
    net_returns = positions * returns - costs
    equity = float(initial_capital) * (1.0 + net_returns).cumprod()
    peak = equity.cummax()
    drawdown = equity / peak - 1.0
    benchmark = float(initial_capital) * (1.0 + returns).cumprod()
    split = max(1, int(len(x) * (1.0 - test_fraction)))
    oos = net_returns.iloc[split:]
    oos_equity = (1.0 + oos).cumprod()
    oos_peak = oos_equity.cummax()
    oos_dd = oos_equity / oos_peak - 1.0
    daily_std = float(net_returns.std(ddof=1)) if len(net_returns) > 1 else 0.0
    active = positions != 0
    trades = _trade_segments(x.Close, positions, net_returns)
    wins = int((trades.Result == "WIN").sum()) if not trades.empty else 0
    losses = int((trades.Result == "LOSS").sum()) if not trades.empty else 0
    gross_profit = float(trades.loc[trades["Net return %"] > 0, "Net return %"].sum()) if not trades.empty else 0.0
    gross_loss = float(-trades.loc[trades["Net return %"] < 0, "Net return %"].sum()) if not trades.empty else 0.0
    metrics = {
        "strategy": strategy, "candles": int(len(x)), "initial_capital": float(initial_capital),
        "final_equity": float(equity.iloc[-1]), "net_return_pct": float((equity.iloc[-1] / initial_capital - 1) * 100),
        "buy_hold_return_pct": float((benchmark.iloc[-1] / initial_capital - 1) * 100),
        "max_drawdown_pct": float(drawdown.min() * 100),
        "sharpe_approx": float(net_returns.mean() / daily_std * np.sqrt(252)) if daily_std > 0 else None,
        "trade_count": int(len(trades)), "win_rate_pct": float(wins / len(trades) * 100) if len(trades) else None,
        "profit_factor": gross_profit / gross_loss if gross_loss > 0 else (float("inf") if gross_profit > 0 else None),
        "exposure_pct": float(active.mean() * 100), "estimated_turnover_cost_pct": float(costs.sum() * 100),
        "oos_start": str(x.index[split]) if split < len(x) else "—",
        "oos_return_pct": float((oos_equity.iloc[-1] - 1) * 100) if len(oos_equity) else 0.0,
        "oos_max_drawdown_pct": float(oos_dd.min() * 100) if len(oos_dd) else 0.0,
        "oos_candles": int(len(oos)),
    }
    curve = pd.DataFrame({"Strategy equity": equity, "Buy & hold equity": benchmark,
                          "Drawdown %": drawdown * 100, "Position": positions,
                          "Strategy return %": net_returns * 100}, index=x.index)
    return metrics, curve, trades


def compare_strategies(frame: pd.DataFrame, **kwargs) -> pd.DataFrame:
    rows = []
    for name in STRATEGIES:
        try:
            metrics, _, _ = run_backtest(frame, name, **kwargs)
            rows.append({"Strategy": name, "Net return %": metrics["net_return_pct"],
                         "Max drawdown %": metrics["max_drawdown_pct"],
                         "Trades": metrics["trade_count"], "Win rate %": metrics["win_rate_pct"],
                         "OOS return %": metrics["oos_return_pct"], "Profit factor": metrics["profit_factor"]})
        except ValueError as exc:
            rows.append({"Strategy": name, "Error": str(exc)})
    return pd.DataFrame(rows)
