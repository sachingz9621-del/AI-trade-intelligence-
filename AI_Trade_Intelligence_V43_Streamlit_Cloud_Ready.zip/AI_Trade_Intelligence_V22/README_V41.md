# V41 – Performance Analytics + Dedicated AI Command Centre + Market & Option Chain Assistant

V41 is additive to V40 and retains prior pages/modules. It adds three navigation destinations:

1. **V41 Performance Analytics** – reads the V39 local paper-execution ledger and reports closed-trade count, win rate, net/gross P&L, estimated fees, profit factor, average win/loss, daily/cumulative P&L, outcome distribution, open positions and CSV export. It does not fabricate trades and does not claim to include external broker fills.
2. **Central AI Command Centre** – a dedicated standalone dashboard for the existing V35 Central AI Brain. It displays the selected instrument's rule-based evidence score, direction, evidence, warnings and reference levels, plus the 25 specialist-tool catalogue. It reuses the V35 engine rather than creating a duplicate brain.
3. **AI Market & Option Chain Assistant** – a separate assistant dashboard inspired by the supplied reference screenshot. It presents market snapshot metrics and separate Scalping, Intraday and Hedging assessments, plus Chart & History, Option Chain and News & AI Context tabs. Each strategy card displays bias, summary, ATR reference entry/stop/target and risk/reward only when the available candle evidence supports a directional candidate.

## Data integrity and limitations
- The strategy helper is deterministic/rule-based, not a trained autonomous model.
- It uses the selected sidebar symbol, interval and loaded OHLCV history. Scalping assessments require an appropriately granular 1m/5m data feed; daily candles are not silently treated as intraday ticks.
- Hedging does not invent option strikes, expiry, premiums, IV, Greeks or hedge ratios. Those require verified option-chain data and portfolio exposure from connected modules.
- PCR, IV, news, FII/DII and exchange-live prices are shown only where existing source modules provide them. The assistant does not fill gaps with sample figures.
- Strategy levels are ATR-based reference levels, not guaranteed execution prices or personal financial advice. No real-money orders are placed.
- Performance Analytics reads only the V39 SQLite paper ledger available on the machine running Streamlit. Keep local DB backups; this ZIP does not bundle private databases or credentials.

## Run
`python -m pip install -r requirements.txt`
`python -m streamlit run app.py`
