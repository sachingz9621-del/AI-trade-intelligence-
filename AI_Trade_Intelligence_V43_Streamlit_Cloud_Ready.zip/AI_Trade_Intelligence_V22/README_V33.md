# V33 – Advanced Multi-Asset Scanner

Adds a manual, read-only scanner for Indian indices, a curated NSE large-cap list, commodities, forex and crypto. Each symbol is assessed on hourly and daily OHLCV using the existing EMA/RSI/relative-volume confluence logic.

## Use
1. Run `streamlit run app.py`.
2. Open **V33 Multi-Asset AI Scanner** in the sidebar.
3. Select asset classes, set the per-class symbol limit and score threshold, then click **Run multi-asset scan**.
4. Review aligned candidates, timeframe conflicts, insufficient-data rows and the CSV export.

## Data and limitations
- Uses the application's existing Yahoo Finance history loader (`yfinance`); coverage, delays, intervals and symbol availability vary.
- Commodity, forex and crypto tickers are indicative Yahoo symbols/proxies, not a verified live exchange feed.
- Uses 1-hour (3mo) and daily (6mo) candles. It does not validate options OI, order-book depth, bid/ask spreads, funding rates, exchange session status or tradability.
- Scores are transparent rule-based screening values, not probabilities, forecasts or recommendations. No orders are sent.
- Scan is button-triggered to avoid unnecessary repeated requests and is cached through the app's existing market-data loader.
