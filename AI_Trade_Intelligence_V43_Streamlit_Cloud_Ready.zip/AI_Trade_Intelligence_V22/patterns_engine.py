"""V11 price-action research tools. OHLCV-only, descriptive and non-predictive by default."""
from __future__ import annotations
import numpy as np
import pandas as pd

REQ = {"Open", "High", "Low", "Close", "Volume"}

def _clean(df: pd.DataFrame) -> pd.DataFrame:
    if not REQ.issubset(df.columns):
        raise ValueError("OHLCV data must contain Open, High, Low, Close and Volume")
    x = df.copy().sort_index()
    for c in REQ:
        x[c] = pd.to_numeric(x[c], errors="coerce")
    return x.dropna(subset=["Open", "High", "Low", "Close"])

def detect_candlestick_patterns(df: pd.DataFrame) -> pd.DataFrame:
    x = _clean(df)
    o, h, l, c = x.Open, x.High, x.Low, x.Close
    body = (c-o).abs(); rng = (h-l).replace(0, np.nan)
    upper = h - pd.concat([o,c], axis=1).max(axis=1)
    lower = pd.concat([o,c], axis=1).min(axis=1) - l
    prev_o, prev_c = o.shift(), c.shift()
    out = pd.DataFrame(index=x.index)
    out["Doji"] = body/rng <= 0.10
    out["Hammer"] = (lower >= body*2) & (upper <= body*0.5) & (body/rng <= 0.35)
    out["Shooting Star"] = (upper >= body*2) & (lower <= body*0.5) & (body/rng <= 0.35)
    out["Bullish Engulfing"] = (prev_c < prev_o) & (c > o) & (o <= prev_c) & (c >= prev_o)
    out["Bearish Engulfing"] = (prev_c > prev_o) & (c < o) & (o >= prev_c) & (c <= prev_o)
    out["Inside Bar"] = (h < h.shift()) & (l > l.shift())
    out = out.fillna(False)
    return out

def detect_chart_setups(df: pd.DataFrame, lookback: int = 80, tolerance: float = 0.012) -> list[dict]:
    x = _clean(df).tail(max(lookback, 30))
    if len(x) < 30: return []
    highs, lows = x.High, x.Low
    # Confirmed local pivots: one bar on either side. Last bar is not treated as a pivot.
    ph = highs[(highs > highs.shift(1)) & (highs >= highs.shift(-1))].dropna()
    pl = lows[(lows < lows.shift(1)) & (lows <= lows.shift(-1))].dropna()
    found=[]
    if len(ph) >= 2:
        a,b=float(ph.iloc[-2]),float(ph.iloc[-1])
        if abs(a-b)/max((a+b)/2,1e-9) <= tolerance:
            found.append({"Setup":"Possible double top", "Bias":"Bearish below neckline", "Level":float(x.Low.loc[ph.index[-2]:ph.index[-1]].min()), "Evidence":"Two nearby confirmed swing highs; needs neckline break"})
    if len(pl) >= 2:
        a,b=float(pl.iloc[-2]),float(pl.iloc[-1])
        if abs(a-b)/max((a+b)/2,1e-9) <= tolerance:
            found.append({"Setup":"Possible double bottom", "Bias":"Bullish above neckline", "Level":float(x.High.loc[pl.index[-2]:pl.index[-1]].max()), "Evidence":"Two nearby confirmed swing lows; needs neckline break"})
    if not found: found.append({"Setup":"No clear double top/bottom", "Bias":"Unconfirmed", "Level":np.nan, "Evidence":"No matching pair of confirmed pivots in selected lookback"})
    return found

def classify_market_regime(df: pd.DataFrame) -> dict:
    x=_clean(df); c=x.Close
    if len(x)<60: return {"regime":"Insufficient history", "trend":"Unknown", "volatility":"Unknown", "atr_pct":np.nan}
    e20=c.ewm(span=20,adjust=False).mean(); e50=c.ewm(span=50,adjust=False).mean()
    ret=c.pct_change(); vol=float(ret.tail(20).std())
    tr=pd.concat([x.High-x.Low,(x.High-c.shift()).abs(),(x.Low-c.shift()).abs()],axis=1).max(axis=1)
    atr=float(tr.ewm(alpha=1/14,adjust=False).mean().iloc[-1]); atr_pct=atr/float(c.iloc[-1])*100
    trend="Uptrend" if c.iloc[-1]>e20.iloc[-1]>e50.iloc[-1] else "Downtrend" if c.iloc[-1]<e20.iloc[-1]<e50.iloc[-1] else "Sideways / mixed"
    vol_label="High volatility" if vol>ret.rolling(60).std().median()*1.5 else "Low volatility" if vol<ret.rolling(60).std().median()*0.7 else "Normal volatility"
    regime=f"{trend} · {vol_label}"
    return {"regime":regime,"trend":trend,"volatility":vol_label,"atr_pct":atr_pct}

def pattern_history(df: pd.DataFrame, horizon: int = 5) -> pd.DataFrame:
    x=_clean(df); flags=detect_candlestick_patterns(x)
    future=x.Close.shift(-horizon)/x.Close-1
    rows=[]
    for name in flags.columns:
        mask=flags[name] & future.notna()
        vals=future[mask]
        rows.append({"Pattern":name,"Occurrences":int(mask.sum()),"Positive forward return %":float((vals>0).mean()*100) if len(vals) else np.nan,"Average forward return %":float(vals.mean()*100) if len(vals) else np.nan,"Horizon candles":horizon})
    return pd.DataFrame(rows)

def breakout_context(df: pd.DataFrame, horizon: int = 5) -> dict:
    x=_clean(df)
    if len(x)<80: return {"status":"Insufficient history", "historical_up_rate":np.nan,"historical_down_rate":np.nan,"samples":0,"range_high":np.nan,"range_low":np.nan}
    prior_high=x.High.shift(1).rolling(20).max(); prior_low=x.Low.shift(1).rolling(20).min()
    vol_avg=x.Volume.shift(1).rolling(20).mean().replace(0,np.nan)
    vol_ratio=x.Volume/vol_avg
    # Similar historical compression/volume context, with forward outcomes strictly after signal bar.
    width=(prior_high-prior_low)/x.Close
    width_q=width.rolling(60,min_periods=30).rank(pct=True)
    future_high=x.High.shift(-1).rolling(horizon).max().shift(-horizon) # replaced below with explicit forward windows
    fwd_up=pd.concat([x.High.shift(-i) for i in range(1,horizon+1)],axis=1).max(axis=1)
    fwd_dn=pd.concat([x.Low.shift(-i) for i in range(1,horizon+1)],axis=1).min(axis=1)
    valid=fwd_up.notna() & fwd_dn.notna() & width_q.notna()
    similar=valid & (width_q<=0.35) & (vol_ratio>=1.1)
    up=((fwd_up>prior_high*1.002)&similar)
    down=((fwd_dn<prior_low*0.998)&similar)
    n=int(similar.sum()); up_rate=float(up.sum()/n*100) if n else np.nan; down_rate=float(down.sum()/n*100) if n else np.nan
    last=float(x.Close.iloc[-1]); rh=float(prior_high.iloc[-1]); rl=float(prior_low.iloc[-1]); vr=float(vol_ratio.iloc[-1]) if pd.notna(vol_ratio.iloc[-1]) else np.nan
    status="Range breakout above" if last>rh else "Range breakdown below" if last<rl else "Inside 20-candle range"
    return {"status":status,"historical_up_rate":up_rate,"historical_down_rate":down_rate,"samples":n,"range_high":rh,"range_low":rl,"volume_ratio":vr,"compression_percentile":float(width_q.iloc[-1]*100) if pd.notna(width_q.iloc[-1]) else np.nan}

def optimize_ema_strategy(df: pd.DataFrame, cost_bps: float=10.0) -> tuple[pd.DataFrame, dict]:
    """Small grid search on chronological training segment; report selected strategy on untouched holdout."""
    x=_clean(df); c=x.Close
    if len(x)<180: raise ValueError("Need at least 180 candles for chronological strategy optimization")
    split=int(len(x)*0.70); train=c.iloc[:split]; test=c.iloc[split:]
    rows=[]
    for fast in (8,12,20):
        for slow in (30,50,100):
            if fast>=slow: continue
            f=train.ewm(span=fast,adjust=False).mean(); s=train.ewm(span=slow,adjust=False).mean()
            pos=(f>s).astype(float)
            r=train.pct_change().fillna(0); turnover=pos.diff().abs().fillna(pos.iloc[0])
            net=pos*r-turnover*cost_bps/10000
            rows.append({"Fast EMA":fast,"Slow EMA":slow,"Train return %":(np.prod(1+net)-1)*100,"Train trades":int((turnover>0).sum())})
    grid=pd.DataFrame(rows).sort_values("Train return %",ascending=False).reset_index(drop=True)
    best=grid.iloc[0]; fast=int(best["Fast EMA"]); slow=int(best["Slow EMA"])
    # Apply fixed parameters to holdout; EMAs are warmed up with full past data, positions use previous close.
    ef=c.ewm(span=fast,adjust=False).mean(); es=c.ewm(span=slow,adjust=False).mean()
    pos=(ef>es).astype(float).shift(1).fillna(0).iloc[split:]
    rets=c.pct_change().fillna(0).iloc[split:]
    turnover=pos.diff().abs().fillna(pos.iloc[0])
    net=pos*rets-turnover*cost_bps/10000
    equity=(1+net).cumprod()
    result={"fast_ema":fast,"slow_ema":slow,"holdout_return_pct":float((equity.iloc[-1]-1)*100),"holdout_max_drawdown_pct":float((equity/equity.cummax()-1).min()*100),"holdout_samples":int(len(test)),"train_samples":int(split),"cost_bps":float(cost_bps)}
    curve=pd.DataFrame({"Strategy equity":equity,"Buy & hold equity":(1+rets).cumprod()},index=test.index)
    return grid,result,curve

def rank_opportunities(items: list[dict]) -> pd.DataFrame:
    """Ranks provided OHLCV-derived summaries; score is a heuristic, not a probability."""
    rows=[]
    for item in items:
        score=float(item.get("trend_score",0))
        if item.get("breakout",False): score+=2
        if item.get("volume_ratio",0)>=1.5: score+=1
        if item.get("regime_trend")=="Sideways / mixed": score-=0.5
        rows.append({"Symbol":item.get("symbol",""),"Heuristic score":score,"Trend score":item.get("trend_score",0),"Regime":item.get("regime",""),"Volume ratio":item.get("volume_ratio",np.nan),"Breakout":bool(item.get("breakout",False))})
    return pd.DataFrame(rows).sort_values("Heuristic score",ascending=False).reset_index(drop=True) if rows else pd.DataFrame()
