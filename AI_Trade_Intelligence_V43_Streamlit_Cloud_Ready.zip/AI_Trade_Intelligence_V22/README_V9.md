# AI Trade Intelligence V9 – Professional Market Dashboard

V9 builds on the V8 project and adds a consolidated dashboard, sample market breadth, sector-strength ranking, locally persisted price alerts, and a locally persisted trade journal.

## Run

1. Extract this ZIP.
2. Open a terminal in the `AI_Trade_Intelligence` folder.
3. Install dependencies: `python -m pip install -r requirements.txt`
4. Start: `python -m streamlit run app.py`

## New V9 pages

- **Professional Market Dashboard** – NIFTY/index and global-market snapshot plus sector performance.
- **Market Breadth & Sector Strength** – advancing/declining count for a configured sample basket and sector ranking.
- **Market Alerts** – create Above/Below price alerts for Yahoo Finance symbols. Alerts are evaluated when the page is opened and the user presses Check; they are not background/push alerts.
- **Portfolio & Trade Journal** – closed trades are stored in `ati_v9_data.sqlite3` in the project folder, so they persist across app restarts on the same machine.

## Important limitations

- Yahoo Finance data can be delayed, incomplete, rate-limited, or unavailable. It is not an exchange-grade live feed.
- Breadth uses a limited configured sample of large-cap symbols, not all NSE stocks or official exchange breadth.
- Sector proxies/index symbols may be unavailable from Yahoo Finance at times.
- Alerts require the Streamlit app to be running and checked manually; no background service or mobile notification is included.
- The journal is manual and local. It does not connect to broker holdings, orders, or positions.
- No order placement or automated trading is enabled. Signals and analytics are informational, not guaranteed predictions.

## Upstox credentials

Copy `.streamlit/secrets.toml.example` to `.streamlit/secrets.toml` and enter your own access token locally. Never share the token or include it in a ZIP.

## Data backup

Back up `ati_v9_data.sqlite3` to preserve locally saved alerts and journal entries. Do not delete it unless you want to reset local data.
