# V18 – Intraday Opportunity Scanner

V18 builds on the V17 project and adds a multi-symbol, read-only scanner using the existing 5-minute / 15-minute confluence engine.

## Run

```powershell
python -m pip install -r requirements.txt
python -m streamlit run app.py
```

Open **V18 Opportunity Scanner**, enter Yahoo Finance ticker symbols (NSE examples use `.NS`), and click **Scan intraday opportunities**. Results can be downloaded as CSV.

## Data and limitations

- Uses Yahoo Finance intraday OHLCV history through the existing `load_data` function.
- Scans up to 15 symbols per run; availability and rate limits depend on Yahoo Finance.
- `ALIGNED` means the 5-minute and 15-minute heuristic biases agree. Scores are not calibrated probabilities or trade recommendations.
- No Upstox streaming feed or order placement is used by this module.
- No signal is generated when data is missing or insufficient.

V17 modules and existing project files are retained.
