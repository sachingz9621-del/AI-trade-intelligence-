"""V22 multi-timeframe signal quality and risk context.

Transparent OHLCV heuristics only. No machine-learning probability, order-flow
verification, broker execution, or investment advice.
"""
from __future__ import annotations
import pandas as pd
from intraday_signal_engine import timeframe_snapshot

TIMEFRAME_ORDER = ("5m", "15m", "1H", "1D")


def _freshness(frame: pd.DataFrame | None, label: str) -> dict:
    if frame is None or frame.empty:
        return {"status": "Unavailable", "age_hours": None, "latest": None}
    try:
        stamp = pd.Timestamp(frame.index[-1])
        if stamp.tzinfo is None:
            stamp = stamp.tz_localize("UTC")
        else:
            stamp = stamp.tz_convert("UTC")
        age = max(0.0, (pd.Timestamp.now(tz="UTC") - stamp).total_seconds() / 3600)
        # Generous thresholds avoid treating normal overnight/weekend closures as feed failures.
        limit = 96 if label in ("5m", "15m", "1H") else 240
        status = "Fresh" if age <= limit else "Potentially stale"
        return {"status": status, "age_hours": round(age, 1), "latest": stamp.isoformat()}
    except Exception:
        return {"status": "Timestamp unavailable", "age_hours": None, "latest": None}


def assess_signal_quality(frames: dict[str, pd.DataFrame], news: pd.DataFrame | None = None) -> dict:
    """Combine supplied timeframe readings and high-priority news risk context."""
    snapshots, freshness = {}, {}
    for label in TIMEFRAME_ORDER:
        frame = frames.get(label)
        if frame is None or frame.empty:
            snapshots[label] = {"timeframe": label, "bias": "INSUFFICIENT DATA", "score": 0,
                                "reasons": ["No candles supplied"], "close": None,
                                "rsi": None, "relative_volume": None}
        else:
            snapshots[label] = timeframe_snapshot(frame, label)
        freshness[label] = _freshness(frame, label)

    ready = [v for v in snapshots.values() if v["bias"] in ("BULLISH", "BEARISH", "NEUTRAL")]
    bulls = sum(v["bias"] == "BULLISH" for v in ready)
    bears = sum(v["bias"] == "BEARISH" for v in ready)
    neutrals = sum(v["bias"] == "NEUTRAL" for v in ready)
    if not ready:
        direction = "WAIT — INSUFFICIENT DATA"
        agreement = "No valid timeframe readings"
    elif bulls == len(ready):
        direction, agreement = "BULLISH ALIGNMENT", "All available timeframes bullish"
    elif bears == len(ready):
        direction, agreement = "BEARISH ALIGNMENT", "All available timeframes bearish"
    elif bulls > bears:
        direction, agreement = "BULLISH LEAN — MIXED", "Bullish readings outnumber bearish readings"
    elif bears > bulls:
        direction, agreement = "BEARISH LEAN — MIXED", "Bearish readings outnumber bullish readings"
    else:
        direction, agreement = "WAIT — CONFLICTING", "No directional majority"

    stale = [k for k, v in freshness.items() if v["status"] == "Potentially stale" and snapshots[k]["bias"] != "INSUFFICIENT DATA"]
    high_news = pd.DataFrame()
    if news is not None and not news.empty:
        n = news.copy()
        if "Priority score" not in n.columns:
            from market_intelligence_v21 import enrich_news
            n = enrich_news(n)
        if "Priority score" in n.columns:
            high_news = n[pd.to_numeric(n["Priority score"], errors="coerce").fillna(0) >= 65].head(8)

    warnings = []
    if len(ready) < 3:
        warnings.append("Fewer than three timeframes have usable candles; confirmation is incomplete.")
    if stale:
        warnings.append("Potentially stale candles: " + ", ".join(stale) + ". Refresh and verify timestamps.")
    if not high_news.empty:
        warnings.append("High-priority market headlines are present. Review event risk before acting.")
    if direction.startswith("WAIT"):
        warnings.append("No directional setup is confirmed by the available timeframe readings.")

    if len(ready) >= 3 and ((bulls == len(ready)) or (bears == len(ready))) and not stale:
        quality = "STRONG ALIGNMENT"
    elif len(ready) >= 2 and (bulls >= 2 or bears >= 2) and not stale:
        quality = "PARTIAL ALIGNMENT"
    else:
        quality = "LOW / INCOMPLETE"
    return {"direction": direction, "agreement": agreement, "quality": quality,
            "bullish_count": bulls, "bearish_count": bears, "neutral_count": neutrals,
            "available_count": len(ready), "timeframes": snapshots, "freshness": freshness,
            "high_priority_news": high_news, "warnings": warnings,
            "disclaimer": "Rule-based OHLCV screening only. Quality labels are not probabilities or guaranteed forecasts. News priority is keyword-based; verify source, timestamp, broker quotes, liquidity, spreads and event details."}
