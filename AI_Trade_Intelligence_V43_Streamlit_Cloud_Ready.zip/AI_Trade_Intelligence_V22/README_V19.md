# AI Trade Intelligence V19 — Multi-Source News

## What's new
- New **Multi-Source News & Forex Factory** page.
- India headlines: Economic Times Markets, Mint Markets, Business Standard and The Hindu BusinessLine.
- International headlines: CNBC Markets, BBC Business, MarketWatch, Bloomberg Markets and Financial Times.
- Policy/macro news search for RBI and SEBI, plus Federal Reserve releases.
- Forex Factory's public weekly XML economic calendar (when reachable) and a direct link to its curated News page.
- Source health/status table, duplicate-link removal, publication timestamps and refresh control.

## Important distinction
Forex Factory's curated **News** product is a web page, while its public XML endpoint is an **economic calendar**. This build links to the curated News page and parses the calendar separately; it does not mislabel calendar events as news stories.

## Install / run
```powershell
python -m pip install -r requirements.txt
python -m streamlit run app.py
```

Open **Multi-Source News & Forex Factory** from the sidebar.

## Data and limitations
- Yahoo Finance is no longer the only source for news. It remains the price-history provider for existing chart/scanner modules; this news page uses independent RSS/XML publishers.
- RSS availability and terms are controlled by each publisher. Feeds may be blocked, changed or temporarily unavailable. The page reports each source's status and links to original stories.
- News headlines are not trading signals. Check the linked original article and verify event times before making decisions.
- Forex Factory calendar events may be in the publisher's local timezone; confirm the displayed event time on Forex Factory before trading.
- This is a news aggregation enhancement, not a licensed redistribution service. Review each publisher's RSS terms before any public/commercial deployment.
