# V39 — Paper Execution Simulator

V39 adds a local, deterministic paper-execution simulator to the existing V38 terminal project. It is simulation-only and contains no broker order routes.

## Added capabilities
- Paper order ticket for MARKET, LIMIT, STOP_MARKET and STOP_LIMIT orders.
- Order lifecycle: PENDING → TRIGGERED (for stop orders) → FILLED, or CANCELLED.
- Explicit price evaluation: market orders use the latest available historical close; pending orders are evaluated only when the user requests evaluation using available history or enters an observed price.
- Adverse slippage model and configurable brokerage, exchange, regulatory, other-tax and slippage basis-point assumptions.
- Separate simulated positions with manual close, gross/net P&L and estimated round-trip fees.
- Persistent local order, position and event history in `ati_v39_paper_execution.sqlite3`.
- Performance summary for closed positions.

## Important simulation limits
No real broker/exchange routing, live order book, queue priority, partial fills, latency, market impact, margin engine, statutory tax calculation, or guaranteed real-time quote is implemented. Stop-market gap behavior is simplified to the observed price supplied during evaluation. The cost assumptions are editable estimates, not actual broker charges. Every fill is a simulated fill.

## Data preservation
V39 is additive. It does not modify the V34 portfolio database, V37 paper-trade database, or V38 watchlist/alert database. Local database files are created at runtime and are not included in this source ZIP. Keep local DB backups when moving installations.

## Run
`python -m pip install -r requirements.txt`
`python -m streamlit run app.py`

## Test
`pytest -q test_sim_execution_v39.py test_platform_ultimate_v37.py test_terminal_v38.py`
