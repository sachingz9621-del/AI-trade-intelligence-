"""Multi-source market news and macro calendar aggregator (RSS/XML, headlines only)."""
from __future__ import annotations
import re
import xml.etree.ElementTree as ET
from datetime import datetime, timezone
from email.utils import parsedate_to_datetime
from urllib.parse import urlparse
import requests
import pandas as pd

NEWS_FEEDS = [
    # India
    ("Economic Times Markets", "India", "https://economictimes.indiatimes.com/markets/stocks/rss.cms"),
    ("Mint Markets", "India", "https://www.livemint.com/rss/markets"),
    ("Business Standard", "India", "https://www.business-standard.com/rss/markets-106.rss"),
    ("The Hindu BusinessLine", "India", "https://www.thehindubusinessline.com/feeder/default.rss"),
    # International / financial media
    ("CNBC Markets", "International", "https://www.cnbc.com/id/20910258/device/rss/rss.html"),
    ("BBC Business", "International", "https://feeds.bbci.co.uk/news/business/rss.xml"),
    ("MarketWatch", "International", "https://feeds.content.dowjones.io/public/rss/mw_topstories"),
    ("Bloomberg Markets", "International", "https://feeds.bloomberg.com/markets/news.rss"),
    ("Financial Times", "International", "https://www.ft.com/rss/home"),
    # Official policy / macro sources
    ("RBI and SEBI policy news", "Official", "https://news.google.com/rss/search?q=RBI+OR+SEBI+policy+India&hl=en-IN&gl=IN&ceid=IN:en"),
    ("Federal Reserve", "Official", "https://www.federalreserve.gov/feeds/press_all.xml"),
]
FOREX_FACTORY_CALENDAR = "https://www.forexfactory.com/ff_calendar_thisweek.xml"
FOREX_FACTORY_NEWS = "https://www.forexfactory.com/news"
HEADERS = {"User-Agent": "Mozilla/5.0 (compatible; AITradeIntelligence/1.0; +personal-use)"}


def _tag(tag):
    return tag.rsplit("}", 1)[-1].lower()


def _text(node, names):
    for child in list(node):
        if _tag(child.tag) in names and child.text:
            return child.text.strip()
    return ""


def _parse_date(value):
    if not value:
        return ""
    try:
        dt = parsedate_to_datetime(value)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt.astimezone(timezone.utc).isoformat()
    except Exception:
        try:
            return datetime.fromisoformat(value.replace("Z", "+00:00")).astimezone(timezone.utc).isoformat()
        except Exception:
            return value


def fetch_feed(name, category, url, timeout=9):
    try:
        response = requests.get(url, headers=HEADERS, timeout=timeout)
        response.raise_for_status()
        root = ET.fromstring(response.content)
        rows = []
        for node in root.iter():
            if _tag(node.tag) not in ("item", "entry"):
                continue
            title = _text(node, {"title"})
            link = _text(node, {"link"})
            if not link:
                for child in list(node):
                    if _tag(child.tag) == "link":
                        link = child.attrib.get("href", "")
                        if link:
                            break
            published = _text(node, {"pubdate", "published", "updated", "date"})
            summary = _text(node, {"description", "summary", "content"})
            summary = re.sub(r"<[^>]+>", " ", summary)
            summary = re.sub(r"\s+", " ", summary).strip()
            if title and link:
                rows.append({"Source": name, "Category": category, "Headline": title,
                             "Published (UTC)": _parse_date(published), "Summary": summary[:350],
                             "Link": link, "Domain": urlparse(link).netloc})
        return rows, None
    except Exception as exc:
        return [], f"{type(exc).__name__}: {exc}"


def fetch_all_news():
    rows, statuses = [], []
    for name, category, url in NEWS_FEEDS:
        items, error = fetch_feed(name, category, url)
        rows.extend(items)
        statuses.append({"Source": name, "Category": category,
                         "Status": f"OK · {len(items)} headlines" if error is None else "Unavailable",
                         "Details": error or ""})
    if not rows:
        return pd.DataFrame(columns=["Source", "Category", "Headline", "Published (UTC)", "Summary", "Link", "Domain"]), pd.DataFrame(statuses)
    df = pd.DataFrame(rows).drop_duplicates(subset=["Link"])
    df["_sort"] = pd.to_datetime(df["Published (UTC)"], errors="coerce", utc=True)
    df = df.sort_values("_sort", ascending=False, na_position="last").drop(columns="_sort")
    return df.reset_index(drop=True), pd.DataFrame(statuses)


def fetch_forex_factory_calendar(timeout=9):
    """Forex Factory's public XML is an economic calendar, not its curated News feed."""
    try:
        response = requests.get(FOREX_FACTORY_CALENDAR, headers=HEADERS, timeout=timeout)
        response.raise_for_status()
        root = ET.fromstring(response.content)
        rows = []
        for node in root.iter():
            if _tag(node.tag) not in ("event",):
                continue
            item = {_tag(c.tag): (c.text or "").strip() for c in list(node)}
            if any(item.values()):
                rows.append({"Date": item.get("date", ""), "Time": item.get("time", ""),
                             "Currency": item.get("country", ""), "Impact": item.get("impact", ""),
                             "Event": item.get("title", ""), "Actual": item.get("actual", ""),
                             "Forecast": item.get("forecast", ""), "Previous": item.get("previous", "")})
        return pd.DataFrame(rows), None
    except Exception as exc:
        return pd.DataFrame(), f"{type(exc).__name__}: {exc}"
