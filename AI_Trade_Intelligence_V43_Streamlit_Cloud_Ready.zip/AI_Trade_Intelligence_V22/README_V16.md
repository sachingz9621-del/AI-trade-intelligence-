# AI Trade Intelligence V16 — AI Options Strategy Engine

V16 builds on the V15 project and adds a read-only options-contract screening page and an illustrative premium risk calculator.

## Run

```powershell
python -m pip install -r requirements.txt
python -m streamlit run app.py
```

## Use

1. Configure your own Upstox access token locally in `.streamlit/secrets.toml` as `UPSTOX_ACCESS_TOKEN = "..."`.
2. Open **V15 Live Options Intelligence**, load expiries, and fetch an option-chain snapshot.
3. Open **V16 AI Options Strategy Engine**. It reads the fetched snapshot from the current Streamlit session.
4. Adjust the distance, volume and OI filters. Select a displayed contract to calculate an illustrative premium stop/target and quantity based on the lot size you enter.

## How the score works

The transparent 0–100 heuristic awards points for positive OI change, elevated volume/OI, moderate delta, IV at or below 60, and proximity to spot. Decreasing OI and IV above 80 reduce the score. It is a screening score only—not a trained ML model, probability, forecast, or buy/sell instruction. Missing inputs receive no points.

## Important limitations

- V16 does not place orders or connect to an order endpoint.
- V16 uses the last option-chain snapshot fetched in V15; it does not continuously stream option-chain updates.
- Verify lot size against the current exchange contract specification; the calculator default is only a convenience.
- The premium risk plan excludes brokerage, taxes, bid/ask spread, slippage, liquidity effects, gaps and execution failure. The actual loss can exceed the planned stop loss.
- Options can expire worthless. Use independent checks and appropriate risk controls.

## Tests

`pytest -q --ignore=test_market_stream.py` completed with 39 passing tests in the build environment. The separate `test_market_stream.py` collection requires the Upstox SDK (`upstox_client`), which was not installed in that environment; this is not a live-connection test.
