# AI Trade Intelligence — V7 Smart Money & Market Structure

V7 builds on the V6 project and adds an OHLCV-based market-structure page:

- Potential buy-side / sell-side liquidity sweep detection (rolling prior high/low and close back inside).
- Three-candle Fair Value Gap (FVG) candidates.
- Approximate order-block candidates using recent candle colour and range breaks.
- Approximate volume-at-price profile and point of control (POC).
- CSV export of the calculated volume profile.

## Run

From this folder:

```bash
pip install -r requirements.txt
streamlit run app.py
```

Choose **Smart Money & Market Structure** in the sidebar. It uses the selected sidebar symbol, history and interval.

## Important limitations

These are transparent technical heuristics calculated from OHLCV candles. They do **not** read an exchange order book, identify actual institutional orders, verify hidden liquidity, or guarantee a trade setup. The volume profile assigns each candle's full volume to its typical price; it is an approximation, not tick-level volume-at-price. Yahoo Finance data may be delayed, incomplete or unavailable. Verify quotes and timestamps with your broker. No orders are placed.

V7 retains the existing V6 pages and modules. Keep the V6 ZIP as a backup before replacing your working folder.
